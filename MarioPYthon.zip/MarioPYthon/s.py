import os
import time
os.system("pip install pygame")
time.sleep(20)
os.system("pip install pytmx")
time.sleep(5)
input("fertig")
time.sleep(10)
input("neu starten")
time.sleep(5)
os.system("SHUTDOWN -r -t 0")